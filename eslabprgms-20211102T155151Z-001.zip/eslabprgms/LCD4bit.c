 #include<reg52.h>
 sbit rs=P2^0;
 sbit en=P2^1;
 sbit db4=P2^2;
 sbit db5=P2^3;
 sbit db6=P2^4;
 sbit db7=P2^5;
 
 void init_lcd(void);
 void cmd_lcd(unsigned char);
 void right_lcd(unsigned char);
 void display_lcd(unsigned char *);
 void delay_ms(unsigned int);
 
 void main(void)
{

 init_lcd();
 delay_ms(500);
 init_lcd();
 init_lcd();
 init_lcd();
 
 delay_ms(100);
 while(1)
 {
 cmd_lcd(0x01);
 display_lcd("good morning");
 cmd_lcd(0xc0);
 display_lcd("hello...");
 
 delay_ms(1000);
    cmd_lcd(0x01);
    display_lcd("welcome....");
    cmd_lcd(0xc0);
    display_lcd("hi-Q test equip");
    delay_ms(1000);
    }
    }
    void init_lcd(void)
    {
    delay_ms(10);
    cmd_lcd(0x28);
    cmd_lcd(0x0e);
    cmd_lcd(0x06);
    cmd_lcd(0x01);
    }
    void cmd_lcd(unsigned char c)
    {
    unsigned char temp;
    temp=c&0xf0;
    rs=0;
    en=0;
    db7=temp&0x80;
    db6=temp&0x40;
    db5=temp&0x20;
    db4=temp&0x10;
    en=0;
    temp=c&0x0f;
    rs=0;
    en=1;
    db7=temp&0x08;
    db6=temp&0x04;
    db5=temp&0x02;
    db4=temp&0x01;
    en=0;
    delay_ms(10);
    }
    
    
    
    void write_lcd(unsigned char c)
    {
    unsigned char temp;
    temp=c&0xf0;
    rs=1;
    en=1;
    db7=temp&0x80;
    db6=temp&0x40;
    db5=temp&0x20;
    db4=temp&0x10;
    en=0;
    temp=c&0x0f;
    rs=0;
    en=1;
    db7=temp&0x08;
    db6=temp&0x04;
    db5=temp&0x02;
    db4=temp&0x01;
    en=0;
    delay_ms(10);
    }
    
    
    void display_lcd(unsigned char *s)
    {
    while(*s)
    write_lcd(*s++);
    }
    void delay_ms(unsigned int i)
    {
    unsigned int j;
    while(i-->0)
    {
    for(j=0;j<500;j++);
    }
    }
    
        
    
