
//programe to led & relay//
// programed by hiq test equipment//

#include<reg52.h>

void delay_ms(unsigned int);

sbit led1=P2^0;
sbit led2=P2^1;
sbit relay=P2^2;
sbit buzzer=P2^3;
sbit sw1=P1^0;
sbit sw2=P1^1;
sbit sw3=P1^2;
sbit sw4= P1^3;

void main() 
{
                      
while(1)
{
led1=0;
led2=0;
relay=0;
buzzer=0;





while(sw1==0)
{
led1=0;
delay_ms(1000);
led1=1;
delay_ms(1000);
}
while(sw2==0)
{
led2=0;
delay_ms(1000);
led2=1;
delay_ms(1000);
}



while(sw3==0)
{
relay=0;
delay_ms(1000);
relay=1;
delay_ms(1000);
}
while(sw4==0)
{
buzzer=0;
delay_ms(1000);
buzzer=1;
delay_ms(1000);
}

}

}

//generates delay in milli seconds
void delay_ms(unsigned int i)
{
unsigned int j;
	while(i-->0)
	{
		for(j=0;j<500;j++)
		{
			;
		}
	}
}
  

 
