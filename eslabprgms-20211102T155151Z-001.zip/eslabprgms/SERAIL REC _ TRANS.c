//program to implement rs232 serial communication //
//programred by hiq test equipment// 
#include<reg51.h>

sbit rs  = P2^0;
sbit en  = P2^1;
sbit db7 = P2^5;
sbit db6 = P2^4;
sbit db5 = P2^3;
sbit db4 = P2^2;


// initialising lcd functions
unsigned char data1;
bit flag=0;
void init_lcd(void);             
void cmd_lcd(unsigned char);     
void write_lcd(unsigned char);
void display_lcd(unsigned char *);
void delay_ms(unsigned int);

void serial_intr(void) interrupt 4;

unsigned char *s="Transmission OK",*c;
void main(void)
{                                     
init_lcd();
delay_ms(100);
init_lcd();
delay_ms(100);
cmd_lcd(0x01);


TMOD=0x20; //set timer1 to mode2
SCON=0x50; //set serial communication parameters,
			  // mode1=1 start bit, 8 data bits, 1 stop bit, no parity & receive enable
IE=0x90;   //set global interrupt bit EA=1, serial interrupt bit ES=1
TH1=0xfd;  //set 9600 baud rate
TR1=1;     //start timer1
c=s;
cmd_lcd(0x80);
display_lcd("Serial Comm");
while(1)
{

if(flag==1)
{

delay_ms(100);
SBUF=data1;
flag=0;
 }}
}

//interrupt service routine for serial interrupt
void serial_intr(void) interrupt 4
{
	if(TI) //if transmit interrupt, clear TI
	{
	
		TI=0;
	}
	if(RI) //if receive interrupt, clear RI
	{
	flag=1;
		write_lcd(SBUF); //display received byte
		data1=SBUF;
		delay_ms(100);

		RI=0;

		
		}
	}
 

void init_lcd(void)
{                            
delay_ms(1); 
cmd_lcd(0x28);
cmd_lcd(0x0e);
cmd_lcd(0x06);
cmd_lcd(0x01);
}
 
void cmd_lcd ( unsigned char c )
{
  unsigned char temp;
  temp = c & 0xf0;         //Transmitting high byte
   rs = 0;
  en = 1;
  db7 = temp & 0x80;
  db6 = temp & 0x40;
  db5 = temp & 0x20;
  db4 = temp & 0x10;
  en = 0;
  temp = c & 0x0f;          //Transmitting low byte
  rs = 0;
  en = 1;
  db7 = temp & 0x08;
  db6 = temp & 0x04;
  db5 = temp & 0x02;
  db4 = temp & 0x01;
  en = 0;        
   delay_ms(10);
}
void write_lcd ( unsigned char c )
{
  unsigned char temp;
  temp = c & 0xf0;        //Transmitting high byte
  rs = 1;
  en = 1;
  db7 = temp & 0x80;
  db6 = temp & 0x40;
  db5 = temp & 0x20;
  db4 = temp & 0x10;
  en = 0;
  temp = c & 0x0f;             //Transmitting low byte
   rs = 1;
  en = 1;
  db7 = temp & 0x08;
  db6 = temp & 0x04;
  db5 = temp & 0x02;
   db4 = temp & 0x01;
  en = 0;        
  delay_ms(10); 

}
void display_lcd(unsigned char *s)
{
while(*s)
write_lcd(*s++);
}

void delay_ms(unsigned int i)
{
unsigned int j;
	while(i-->0)
	{
		for(j=0;j<500;j++)
		{
			;
		}
	}
}
  

 
