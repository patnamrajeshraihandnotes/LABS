/*Program to interface external interrupt to switches// 
/*programed by hiq test equipment***/
#include<reg51.h> //include at89c51 microcontoller header file

//#define led P0 //connect lower nibble of p0 to leds


sbit rs  = P1^0;
sbit en  = P1^1;
sbit db7 = P1^5;
sbit db6 = P1^4;
sbit db5 = P1^3;
sbit db4 = P1^2;


void init_lcd(void);
void cmd_lcd(unsigned char);
void write_lcd(unsigned char);
void display_lcd(unsigned char *);
void delay_ms(unsigned int);

sbit sw1=P3^7;
sbit sw2=P3^6;
sbit sw3=P3^5;
sbit sw4=P3^4;

sbit led1=P0^0;
sbit led2=P0^1;
sbit led3=P0^2;
sbit led4=P0^3;

fun0();
fun1();
fun2();
fun3();
fun4();


//sbit led1=P0^0;
//sbit led2=P0^1;
void delay_ms(unsigned int);
void external_intruppet0(void) interrupt 0;
int flag=0;


void main(void)
{
init_lcd();
delay_ms(500);
init_lcd();
init_lcd();
display_lcd("hi");
delay_ms(1000);
cmd_lcd(0x01);

IE=0x81; 
IT0=1;  




	
	while(1) 
	{  
	                     		
	   if(flag==1)
		{
		flag=0;
		init_lcd();
		if(sw1==1&&sw2==1&&sw3==1&&sw4==1)
	{
	cmd_lcd(0x01);
		fun0();
	}
else if(sw1==0&&sw2==1&&sw3==1&&sw4==1)
	{
		
		fun1();
			}
	
else if(sw1==1&&sw2==0&&sw3==1&&sw4==1)
	{
	
    
	   fun2();
	  }  
   
   else if(sw1==1&&sw2==1&&sw3==0&&sw4==1)
   {

  fun3();
   cmd_lcd(0x01);
   display_lcd("HI to ALL");
   }
   else if(sw1==1&&sw2==1&&sw3==1&&sw4==0)
   {

   fun4();
  }

}
}
}

void init_lcd(void)
{
delay_ms(10);
cmd_lcd(0x28);
cmd_lcd(0x0c);
cmd_lcd(0x06);
cmd_lcd(0x01);
}
void cmd_lcd(unsigned char c)
{
unsigned char temp;
temp = c & 0xf0;
rs = 0;
en = 1;
db7 = temp & 0x80;
db6 = temp & 0x40;
db5 = temp & 0x20;
db4 = temp & 0x10;
en = 0;
temp = ( c & 0x0f ) << 4;
rs = 0;
en = 1;
db7 = temp & 0x80;
db6 = temp & 0x40;
db5 = temp & 0x20;
db4 = temp & 0x10;
en = 0;
delay_ms(2);
}
void write_lcd(unsigned char c)
{
unsigned char temp;
temp = c & 0xf0;
rs = 1;
en = 1;
db7 = temp & 0x80;
db6 = temp & 0x40;
db5 = temp & 0x20;
db4 = temp & 0x10;
en = 0;
temp = ( c & 0x0f ) << 4;
rs = 1;
en = 1;
db7 = temp & 0x80;
db6 = temp & 0x40;
db5 = temp & 0x20;
db4 = temp & 0x10;
en = 0;
delay_ms(2);
}
void display_lcd(unsigned char *s)
{
while(*s)
write_lcd(*s++);
}

void delay_ms(unsigned int i)
{
unsigned int j;
	while(i-->0)
	{
	for(j=0;j<500;j++);
	}
}

		
	


void external_interrupt0(void) interrupt 0 
{					 
EX0=0;    
flag=1;   
 delay_ms(200);
EX0=1;    
}


  fun0()
 {
 //while((sw1==1)&&(sw2==1)&&(sw3==1)&&(sw4==1))
 {
 led1=1;
 led2=1;
 led3=1;
 led4=1;
 delay_ms(500);
 led1=0;
 led2=0;
 led3=0;
 led4=0;
 delay_ms(500);
 }
 }
 
 
 fun1()
 {
// while((sw1==1)&&(sw2==1)&&(sw3==1)&&(sw4==1))
 {
cmd_lcd(0x01); 
		display_lcd("Good Morning");

 led1=0;
 led2=1;
 led3=1;
 led4=1;
 delay_ms(500);
 led1=0;
 led2=0;
 led3=0;
 led4=0;
 delay_ms(500);
 
 }
 }
 

 fun2()
  {
// while((sw1==1)&&(sw2==1)&&(sw3==1)&&(sw4==1))
  {
  cmd_lcd(0x01); 
	   display_lcd("Hello Everybody");
	
   led1=1;
 led2=0;
 led3=1;
 led4=1;
 delay_ms(500);
 led1=0;
 led2=0;
 led3=0;
 led4=0;
 delay_ms(500);
 }
}

 fun3()
   {
  //while((sw1==1)&&(sw2==1)&&(sw3==1)&&(sw4==1))
  {
   cmd_lcd(0x01);
   display_lcd("HI to ALL");

   led1=1;
 led2=1;
 led3=0;
 led4=1;
 delay_ms(500);
 led1=0;
 led2=0;
 led3=0;
 led4=0;
 delay_ms(500);
  }
 }

 fun4()
  {
//while((sw1==1)&&(sw2==1)&&(sw3==1)&&(sw4==1))
  {
   cmd_lcd(0x01);
   display_lcd("HELLO to ALL");

   led1=1;
	led2=1;
	led3=1;
 	led4=0;
 	delay_ms(500);
 	led1=0;
 	led2=0;
 	led3=0;
 	led4=0;
 	delay_ms(500);
  }
 } 


 
 
 
