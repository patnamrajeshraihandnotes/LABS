
#include<reg51.h> 
#include<krdcl.h>

sbit led1 =P1^0;
sbit led2 =P1^1;
                                           // Creating the two tasks
void task1_led(void);   //             
void task2_led(void);
void delay_ms(unsigned char i);

void main()
{
  led1=0;
  led2=0;
 while(1){
  task1_led();
  delay_ms(20);
  task2_led();
  delay_ms(20);
 }
}

void task1_led(void)
{
  led1=1;
  delay_ms(10);
  led1=0;
  //delay_ms(20);
}
void task2_led(void)
{
  led2=1;
  delay_ms(200);
  led2=0;
  //delay_ms(20);
}

void delay_ms(unsigned char i)
{
  unsigned char j;
  while(i-->0)
  {
    for(j=0;j<500;j++);
  }
}
  
  


