  //program to implement analog to digital conversion using ADC0808

#include<reg51.h>

sbit rs  = P1^0;
sbit en  = P1^1;
sbit db7 = P1^5;
sbit db6 = P1^4;
sbit db5 = P1^3;
sbit db4 = P1^2;

bit flag=0;
#define ADC P0 //acquires analog to digital coverted data

sbit A0= P2^0; //A0 A1 & A2 are analog input channel selection bits
sbit A1= P2^1;
sbit A2= P2^2;
sbit START= P2^3; //start convesion bit
sbit ALE= P2^4; //Select channel according to A0 A1& A2
sbit EOC= P2^5; //end of conversion bit
void serial_intr(void) interrupt 4;
#define VREF 5.0   //set voltage reference
#define MAX_RES 0xff //set maximum resolution of ADC0808 (8bit)
//#define VREF 2.56    //set voltage reference
//#define MAX_RES 0xff //set maximum resolution of ADC0808 (8bit)
unsigned char c;

unsigned int i;

void init_lcd();
void cmd_lcd(unsigned char);
void write_lcd(unsigned char);
void display_lcd(unsigned char *);
void integer_lcd(int);
void float_lcd(float);
void delay_ms(unsigned int);

float  val=0,f,value=0;
void main(void)
{

	init_lcd();
	init_lcd();
	delay_ms(100);
	init_lcd();
	init_lcd();
  
TMOD=0x20; //set timer1 to mode2
SCON=0x50; //set serial communication parameters,
			  // mode1=1 start bit, 8 data bits, 1 stop bit, no parity & receive enable
IE=0x90;   //set global interrupt bit EA=1, serial interrupt bit ES=1
TH1=0xfd;  //set 9600 baud rate
TR1=1;     //start timer1

display_lcd("ADC");
cmd_lcd(0xc0);
display_lcd("0808");
delay_ms(500);


while(1)
{

for(i=0;i<=9;i++)
{

cmd_lcd(0x01);

A0=0; //set channel 1
A1=0;
A2=0;
ALE=0;
START=0;
 	        START=1; //start conversion
	        ALE=0; //select channel
	        START=0; 
	        while(EOC==0); //wait till end of conversion
	        val=((5.0*ADC)/MAX_RES);
	       /* float_lcd(val );
	        delay_ms(1000);
	        cmd_lcd(0x01);
	        */
	        val=val*10;

	        value=value+val;
	        val=0;
	        cmd_lcd(0x01);
	        
}
 display_lcd("Now Temp is  ");
 cmd_lcd(0xc0);
value=value/10;
float_lcd(value);
delay_ms(1000);	        
SBUF=10;
delay_ms(10);
SBUF=13;
delay_ms(10);


}       
	}
	
	


void init_lcd()
{                            
delay_ms(10);
cmd_lcd(0x28);
cmd_lcd(0x0e);
cmd_lcd(0x06);
cmd_lcd(0x01);
delay_ms(10);
}

void cmd_lcd ( unsigned char c )
{
  unsigned char temp;
  temp = c & 0xf0;         //Transmitting high byte
   rs = 0;
  en = 1;
  db7 = temp & 0x80;
  db6 = temp & 0x40;
  db5 = temp & 0x20;
  db4 = temp & 0x10;
  en = 0;
  temp = c & 0x0f;          //Transmitting low byte
  rs = 0;
  en = 1;
  db7 = temp & 0x08;
  db6 = temp & 0x04;
  db5 = temp & 0x02;
  db4 = temp & 0x01;
  en = 0;        
   delay_ms(2);
}
void write_lcd ( unsigned char c )
{
  unsigned char temp;
  temp = c & 0xf0;        //Transmitting high byte
  rs = 1;
  en = 1;
  db7 = temp & 0x80;
  db6 = temp & 0x40;
  db5 = temp & 0x20;
  db4 = temp & 0x10;
  en = 0;
  temp = c & 0x0f;             //Transmitting low byte
   rs = 1;
  en = 1;
  db7 = temp & 0x08;
  db6 = temp & 0x04;
  db5 = temp & 0x02;
   db4 = temp & 0x01;
  en = 0;        
  delay_ms(2); 
SBUF=c;
}



void display_lcd(unsigned char *s)
{
while(*s)
write_lcd(*s++);

}


void integer_lcd(int n)
{
unsigned char c[6];
unsigned int i=0;
  if(n<0)
  {
    write_lcd('-');
    n=-n;
  }
  if(n==0)
    write_lcd('0');
  while(n>0)
  {
    c[i++]=(n%10)+48;
    n/=10;
  }
  while(i-->=1)
    write_lcd(c[i]);
}

void float_lcd(float f)
{
int n;
float temp;
n=f;
integer_lcd(n);

write_lcd('.');

temp=f-n;
if(temp>=0.00&&temp<=0.0999)
write_lcd('0');
f=temp*100;
n=f;
integer_lcd(n);

}

void delay_ms(unsigned int i)
{
unsigned int j;
	while(i-->0)
	{
		for(j=0;j<500;j++)
		{
			;
		}
	}
}


//interrupt service routine for serial interrupt
void serial_intr(void) interrupt 4
{
	if(TI) //if transmit interrupt, clear TI
{

TI=0;
}
} 






 
 

 
