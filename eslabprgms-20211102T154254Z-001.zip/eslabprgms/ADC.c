//program to implement analog to digital conversion using ADC0808***//
//* programed by hiq test equipment//

#include<reg51.h>

sbit rs  = P2^0;
sbit en  = P2^1;
sbit db7 = P2^5;
sbit db6 = P2^4;
sbit db5 = P2^3;
sbit db4 = P2^2;
sbit sw1=P1^0;
sbit sw2=P1^1;
sbit sw3=P1^2;
sbit sw4=P1^3;
#define ADC P0 //acquires analog to digital coverted data

sbit A0= P3^0; //A0 A1 & A2 are analog input channel selection bits
sbit A1= P3^1;
sbit A2= P3^2;
sbit START= P3^3; //start convesion bit
sbit ALE= P3^4; //Select channel according to A0 A1& A2
sbit EOC= P3^5; //end of conversion bit

#define VREF 5.0   //set voltage reference
#define MAX_RES 0xff //set maximum resolution of ADC0808 (8bit)
//#define VREF 2.56    //set voltage reference
//#define MAX_RES 0xff //set maximum resolution of ADC0808 (8bit)

void init_lcd();
void cmd_lcd(unsigned char);
void write_lcd(unsigned char);
void display_lcd(unsigned char *);
void integer_lcd(int);
void float_lcd(float);
void delay_ms(unsigned int);


	  float  val=0,f;
void main(void)
{



	init_lcd();
	init_lcd();
	delay_ms(100);
	init_lcd();
	init_lcd();
display_lcd("adc 0808");
delay_ms(1000);
cmd_lcd(0x01);
cmd_lcd(0x01);
while(1)
{
if(sw1==0)
{
do{
cmd_lcd(0x01);


A0=0; //set channel 5
A1=0;
A2=0;
ALE=0;
START=0;
display_lcd("adc val of ch5");
		     cmd_lcd(0xc0);
	        START=1; //start conversion
	        ALE=0; //select channel
	        START=0; 
	        while(EOC==0); //wait till end of conversion
	        float_lcd((5.0*ADC)/MAX_RES);
	        display_lcd(" volts");
	        delay_ms(1000);
	       }while((sw2==0)||(sw3==0)||(sw4==0));

	}
	
else if(sw2==0)
{
do{
cmd_lcd(0x01);
delay_ms(300);
A0=1; //set channel 6
A1=0;
A2=0;
ALE=0;
START=0;
display_lcd("adc val of ch6");
		     cmd_lcd(0xc0);
	        START=1; //start conversion
	        ALE=0; //select channel
	        START=0; 
	        while(EOC==0); //wait till end of conversion
	        float_lcd((VREF*ADC)/MAX_RES);
	        display_lcd(" volts");
	        delay_ms(1000);
	        }while((sw1==0)||(sw3==0)||(sw4==0));
	        
	}
	
else if(sw3==0)
{
do{
cmd_lcd(0x01);
delay_ms(300);

A0=0; //set channel 7
A1=1;
A2=0;
ALE=0;
START=0;
display_lcd("adc val of ch7");
		     cmd_lcd(0xc0);
	        START=1; //start conversion
	        ALE=0; //select channel
	        START=0; 
	        while(EOC==0); //wait till end of conversion
	        float_lcd((VREF*ADC)/MAX_RES);
	        display_lcd(" volts");
	        delay_ms(1000);
	
	}while((sw1==0)||(sw2==0)||(sw4==0));
	}
	
else if(sw4==0)
{

do{
cmd_lcd(0x01);
delay_ms(300);

A0=1; //set channel 8
A1=1;
A2=0;
ALE=0;
START=0;
display_lcd("adc val of ch8");
		     cmd_lcd(0xc0);
	        START=1; //start conversion
	        ALE=0; //select channel
	        START=0; 
	        while(EOC==0); //wait till end of conversion
	        float_lcd((VREF*ADC)/MAX_RES);
	        display_lcd(" volts");
	        delay_ms(1000);
}while((sw1==0)||(sw2==0)||(sw3==0));

	}
	
	}	
	}
	
	
	


void init_lcd()
{                            
delay_ms(10);
cmd_lcd(0x28);
cmd_lcd(0x0e);
cmd_lcd(0x06);
cmd_lcd(0x01);
delay_ms(10);
}

void cmd_lcd ( unsigned char c )
{
  unsigned char temp;
  temp = c & 0xf0;         //Transmitting high byte
   rs = 0;
  en = 1;
  db7 = temp & 0x80;
  db6 = temp & 0x40;
  db5 = temp & 0x20;
  db4 = temp & 0x10;
  en = 0;
  temp = c & 0x0f;          //Transmitting low byte
  rs = 0;
  en = 1;
  db7 = temp & 0x08;
  db6 = temp & 0x04;
  db5 = temp & 0x02;
  db4 = temp & 0x01;
  en = 0;        
   delay_ms(2);
}
void write_lcd ( unsigned char c )
{
  unsigned char temp;
  temp = c & 0xf0;        //Transmitting high byte
  rs = 1;
  en = 1;
  db7 = temp & 0x80;
  db6 = temp & 0x40;
  db5 = temp & 0x20;
  db4 = temp & 0x10;
  en = 0;
  temp = c & 0x0f;             //Transmitting low byte
   rs = 1;
  en = 1;
  db7 = temp & 0x08;
  db6 = temp & 0x04;
  db5 = temp & 0x02;
   db4 = temp & 0x01;
  en = 0;        
  delay_ms(2); 

}



void display_lcd(unsigned char *s)
{
while(*s)
write_lcd(*s++);
}

void integer_lcd(int n)
{
unsigned char c[6];
unsigned int i=0;
  if(n<0)
  {
    write_lcd('-');
    n=-n;
  }
  if(n==0)
    write_lcd('0');
  while(n>0)
  {
    c[i++]=(n%10)+48;
    n/=10;
  }
  while(i-->=1)
    write_lcd(c[i]);
}

void float_lcd(float f)
{
int n;
float temp;
n=f;
integer_lcd(n);
write_lcd('.');
temp=f-n;
if(temp>=0.00&&temp<=0.09)
write_lcd('0');
f=temp*100;
n=f;
integer_lcd(n);
}

void delay_ms(unsigned int i)
{
unsigned int j;
	while(i-->0)
	{
		for(j=0;j<500;j++)
		{
			;
		}
	}
}






  
 
