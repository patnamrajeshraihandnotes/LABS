  // program for leds//
  //programed by hiq test equipment// 
   
   
   
   
  #include<reg51.h>
  sbit sw=P0^0;
 
  //sbit led=P1^0;
  #define led P1
  void delay_ms(unsigned int);
  void delay_ms(unsigned int i)

  {
  unsigned int j;
  while(i-->0)
  for(j=0;j<500;j++);
  }

  void main()
  {
  while(1)
  {
  while(sw==1)
  {
  led=0x00;
  delay_ms(500);
  led=0xff; 
  delay_ms(500);
  }
  }
  }

 

